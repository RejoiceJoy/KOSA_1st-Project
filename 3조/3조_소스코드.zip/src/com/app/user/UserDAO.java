package com.app.user;

import java.util.List;
/**
 * 
 * @author 임다솜
 *
 */
public interface UserDAO extends BaseDAO<UserDTO, String> {
}
