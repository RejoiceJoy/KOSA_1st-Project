개발환경
-운영체제 : Windows 10 Pro 
-DBMS : Oracle Database 18c Express Edition 
-개발 및 설계 도구 : Eclipse, Oracle SQL developer20.4, 
	            : SceneBuiler8.5.0 
-개발 언어 : Java 1.8, JavaFX 
-외부 라이브러리 : OJDBC7, JBCRYPT0.4.1 

실행 시 아래와 같은 방법으로 실행해 주세요.
1. Oracle에서 system 계정으로 lib 폴더에 있는 system.sql 실행해 주세요.
2. 1에서 새로 만들어진 project 계정으로 lib 폴더에 있는 project.sql을 실행해 주세요.
3. Y 너만을 비춤체 글꼴 파일 두 개를 모든 사용자용으로 설치해 주세요.
4. 이클립스에서 com.app 패키지 내의 App 클래스가 메인 클래스 입니다.


